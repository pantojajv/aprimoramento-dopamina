import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Rodape from "./components/Rodape";
import Home from "./pages/Home";
import Sobre from "./pages/Sobre";
import Catalogo from "./pages/Catalogo";
import Contato from "./pages/Contato";

function App() {
  return (
    <div>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/sobre" element={<Sobre />} />
        <Route path="/catalogo" element={<Catalogo />} />
        <Route path="/contato" element={<Contato />} />
      </Routes>

      <Rodape />
    </div>
  );
}

export default App;