import styles from "./Rodape.module.css";

function Rodape() {
  return (
    <footer className={styles.rodape}>
      <p>Projeto de React - 2026</p>
    </footer>
  );
}

export default Rodape;