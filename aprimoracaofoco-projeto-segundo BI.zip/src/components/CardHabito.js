import styles from "./CardHabito.module.css";

function CardHabito({ numero, etapa, nome, texto, imagem }) {
  return (
    <article className={styles.card}>
      <img src={imagem} alt={nome} className={styles.foto} />

      <div className={styles.conteudo}>
        <div className={styles.topo}>
          <span className={styles.numero}>{numero}</span>
          <span className={styles.etapa}>{etapa}</span>
        </div>

        <h3 className={styles.nome}>{nome}</h3>
        <p className={styles.texto}>{texto}</p>
      </div>
    </article>
  );
}

export default CardHabito;