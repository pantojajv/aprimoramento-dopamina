import styles from "./Sobre.module.css";

function Sobre() {
  return (
    <main className={styles.sobre}>
      <h1>Sobre</h1>
      <p>
        Tendo em vista que a geração Z é a primeira geração a crescer com acesso irrestrito à internet,
         tendo suas personalidades,sonhos, vontades e habitos moldados por ela, esse projeto tem como objetivo,
          trazer possiveis formas de lidar com o escesso de dopamina gerada pelos algoritimos e trazr informações sobre o assunto,
           de forma que a pessoa possa se informar e buscar ajuda profissional.
      </p>

      <section className={styles.proximoTema}>
        <h2>Próximos temas</h2>
        <p>
         Com o assunto em volta da dopamina sendo muito amplo, os proximos temas abordados poderam ser sobre vicios presentes
          fortemente na atualidade.
         como: redes sociais, jogos, pornografia, drogas e etc. A ideia é trazer informações sobre o assunto, 
         de forma que possam se informar e buscar ajuda profissional.
        </p>
      </section>
    </main>
  );
}

export default Sobre;