import { Link } from "react-router-dom";
import styles from "./Home.module.css";

function Home() {
  return (
    <main className={styles.home}>
      <p className={styles.subtitulo}>Um passo de cada vez</p>
      <h1>Recupere o seu foco</h1>
      <p className={styles.texto}>
       No mundo das redes sociais, a geração Z é a que vem dominando, mas a que custo?
        O excesso de dopamina gerado pelos algoritimos das redes sociais, tem causado problemas de atenção, ansiedade e depressão,
         e a cada dia mais jovens estão se tornando dependentes das redes sociais.
         Veja 6 hábitos que podem ajudar a sair do ciclo de dopamina e retomar o controle da atenção.
      </p>
      <Link to="/catalogo" className={styles.botao}>
        Ver os hábitos
      </Link>
    </main>
  );
}

export default Home;