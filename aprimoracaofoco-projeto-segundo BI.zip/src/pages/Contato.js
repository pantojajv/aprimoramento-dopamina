import styles from "./Contato.module.css";

function Contato() {
  return (
    <main className={styles.contato}>
      <h1>Contato</h1>
      <p>Dúvidas ou sugestões sobre o projeto? Fale comigo:</p>
      <p>melhorandooshabitos@gmail.com</p>
    </main>
  );
}

export default Contato;