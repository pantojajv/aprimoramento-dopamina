import CardHabito from "../components/CardHabito";
import styles from "./Catalogo.module.css";

import detox from "../assets/detox.jpg";
import sono from "../assets/sono.jpg";
import movimento from "../assets/movimento.jpg";
import foco from "../assets/foco.jpg";
import leitura from "../assets/leitura.jpg";
import metas from "../assets/metas.jpg";

function Catalogo() {
  return (
    <main className={styles.pagina}>
      <header className={styles.cabecalho}>
        <h1 className={styles.titulo}>Seis hábitos, em ordem</h1>
        <p className={styles.subtitulo}>
          Essas são seis de várias praticas que podem ajudar e sair do ciclo de dopamina e retomar o controle da atenção. A ideia é começar com hábitos simples, que não exigem muito esforço, e ir aumentando a dificuldade aos poucos.
        </p>
      </header>

      <div className={styles.lista}>
        <CardHabito
          numero="01"
          etapa="Base"
          nome="Sono em dia"
          texto="Muitas vezes a falta de sono causa cansaço e irritabilidade, 
          que nos leva a buscar recompensas rápidas. Dormir bem ajuda a ter mais foco e energia.
           Dica: tenha um horário de sono denifido e busque manter sempre. pelo menos 1 hora antes de dormir evite o uso de celular e telas, celular smepre longe da cama."
          imagem={sono}
        />
        <CardHabito
          numero="02"
          etapa="reação"
          nome="Movimento"
          texto="Buscar formas de se movimentar e exercitar, ajuda a liberar dopamina de forma natural e controlada, ajudando a desviciar o cerebro. Dica: troque um habito por outro
          , por exemplo, ao invés de ficar rolando o celular, vá caminhar ou correr ou pra academia."
          imagem={movimento}
        />
        <CardHabito
          numero="03"
          etapa="Foco"
          nome="Detox digital"
          texto="Em determninadas horas do dia ou  durante estudos, desligar o celular e qualquer contato com as redes sociais, ajuda a treinar o cerebro a conviver com a falta de alta dopamina, e a se concentrar em tarefas mais longas e mais desafiadoras. Dica: desligue as notificações do celular, e se possível, deixe o celular em outro ambiente, para não ter a tentação de olhar."
          imagem={detox}
        />
        <CardHabito
          numero="04"
          etapa="Foco"
          nome="Foco em uma tarefa"
          texto="Analise todas suas tarefas e separe em ordem de prioridades. Deixar claro quais tarefas fazer primeiro, ajuda a manter o foco e a não se perder em tarefas menos importantes. Dica: use uma agenda ou planner para organizar suas tarefas e prioridades."
          imagem={foco}
        />
        <CardHabito
          numero="05"
          etapa="Constância"
          nome="Leitura diária"
          texto="Nem sempre fazer tudo ou fazer o intensivão de leitura é a melhor forma de aprender. Ler todos os dias, mesmo que pouco, ajuda a manter o habito e a se concentrar em tarefas mais longas e desafiadoras. Dica: leia todos os dias, mesmo que seja pouco, e busque ler sobre assuntos que te interessam primeiro, até criar o hábito para ler assuntos que te desafiam."
          imagem={leitura}
        />
        <CardHabito
          numero="06"
          etapa="Constância"
          nome="Metas pequenas"
          texto="Sea realista, metas pequenas e constantes, que podem ser sentidas e alcancadas, ajudam a manter o habito e a se concentrar em tarefas mais longas e desafiadoras. Dica: estabeleça metas pequenas e realistas, que possam ser alcançadas, e vá aumentando a dificuldade aos poucos.
          assim, consiguira  provar a si mesmo que pode e é capaz de alcançar metas maiores e mais desafiadoras."
          imagem={metas}
        />
      </div>
    </main>
  );
}

export default Catalogo;